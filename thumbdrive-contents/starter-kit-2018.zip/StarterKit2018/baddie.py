import pygame
import random

class Baddie:

    #
    # Create a baddie with size (width,height), position (x,y) and color
    #
    def __init__( self, width, height, x, y, color ):
        self.width  = width
        self.height = height
        self.x      = x
        self.y      = y
        self.speed  = 50
        self.color  = color
        self.alive  = True
        self.direction = 0
        return

    #
    # Move the baddie to the left, and up/down a little bit
    # If the baddie reaches the left wall, deactivate it
    #
    def move( self, back_wall, upper_wall, lower_wall, dt ):
        # new location
        new_x = self.x - self.speed * dt
        if random.randint( 0 , 50 ) == 0:
            self.direction = random.randint( -1, 1 )
        new_y = self.y + self.direction * self.speed * dt / 5
        
        # check left wall
        if new_x < back_wall:
            self.setAlive( False )
        else:
            self.x = new_x

        # check upper and lower walls
        if new_y < upper_wall:
            new_y = upper_wall
        elif new_y + self.height > lower_wall:
            new_y = lower_wall - self.height
        self.y = new_y
        
        return self.alive

    def getAlive( self ):
        return self.alive

    def getDimensions( self ):
        return self.x, self.y, self.width, self.height

    def setAlive( self, alive ):
        self.alive = alive
    
    def draw( self, surface ):
        rect = pygame.Rect( int( self.x ), int( self.y ), int( self.width ), int( self.height ) )
        pygame.draw.rect( surface, self.color, rect )
        return
