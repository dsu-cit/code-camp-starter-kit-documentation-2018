import pygame

class Bullet:

    #
    # Creates a new bullet, with size (width,height), position (x,y) and color
    #
    def __init__( self, width, height, x, y, color ):
        self.width  = width
        self.height = height
        self.x      = x
        self.y      = y
        self.speed  = 150
        self.color  = color
        self.alive  = True
        self.hit    = False
        return

    #
    # Deactivates the bullet if its rectangle overlaps with the baddie's rectangle
    # Marks bullet as hitting a baddie.
    #
    def checkHitBaddie( self, baddie ):
        x, y, w, h = baddie.getDimensions( )
        if self.hitRectangle( x, y, w, h ):
            self.setAlive( False )
            self.hit = True
        return

    #
    # Deactivate the bullet if it hits the right wall.
    #
    def checkBackWall( self, back_wall ):
        if ( self.x + self.width ) > back_wall:
            self.setAlive(False)
        return

    #
    # Move bullet to the right, based on speed and time.
    #   
    def move( self, dt ):
        self.x += self.speed * dt
        return

    #
    # Update the active status of the bullet
    #
    def setAlive( self, alive ):
        self.alive = alive
        return

    #
    # Fetch the hit status of the bullet
    #
    def getHit( self ):
        return self.hit

    #
    # Check if the bullet's rectangle overlaps with the rectangle specified by x,y,w,h
    # Returns True or False
    def hitRectangle( self, x, y, w, h ):
        if ( ( ( self.x + self.width ) >= x ) and
             ( self.x <= x + w ) ):
            if ( ( ( self.y + self.height ) >= y ) and
                 ( self.y <= y + h ) ):
                return True
        return False

    #
    # Draw the bullet on the window
    # 
    def draw( self, surface ):
        rect = pygame.Rect( int( self.x ), int( self.y ), int( self.width ), int( self.height ) )
        pygame.draw.rect( surface, self.color, rect )
        return
