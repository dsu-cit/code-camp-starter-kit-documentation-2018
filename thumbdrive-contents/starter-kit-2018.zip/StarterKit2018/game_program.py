import pygame
import random
import spaceship
import baddie

class GameProgram:

    def __init__( self, width, height, frame_rate ):
        # fonts in case you use text
        self.font  = pygame.font.SysFont( "Times New Roman", 36 )
        self.font2 = pygame.font.SysFont( "Courier New", 20 )
        # basic game information
        self.frame_rate = frame_rate
        self.text_color = ( 255, 0, 0 )
        self.width  = width
        self.height = height
        self.upper_limit = self.width / 3
        # spaceship information
        self.spaceship_width = 20
        self.spaceship_height = 10
        self.spaceship_color = (255,255,255)
        x = 0
        y = ( self.height / 2 ) - self.spaceship_height / 2
        self.spaceship = spaceship.Spaceship( self.spaceship_width, self.spaceship_height, x, y, self.spaceship_color )
        # bullet information
        self.bullets = [ ]
        self.bullet_width = 10
        self.bullet_height = 5
        self.bullet_color = (255,255,255)
        # baddie information
        self.baddies = [ ]
        self.baddie_width = 20
        self.baddie_height = 20
        self.baddie_color = (255,0,0)
        return

    def evolve( self, keys, newkeys, buttons, newbuttons, mouse_position, dt ):
        # move the ship
        if pygame.K_LEFT in keys:
            self.spaceship.moveLeft( dt )
        if pygame.K_RIGHT in keys:
            self.spaceship.moveRight( dt, self.upper_limit )
        if pygame.K_UP in keys:
            self.spaceship.moveUp( dt )
        if pygame.K_DOWN in keys:
            self.spaceship.moveDown( dt, self.height )

        # fire bullets
        if pygame.K_SPACE in newkeys:
            new_bullet = self.spaceship.fire( self.bullet_width, self.bullet_height, self.bullet_color )
            self.bullets.append( new_bullet )

        # add baddies
        if random.randint( 1, self.frame_rate/2 ) == 1:
            self.addBaddie( )

        # update bullets
        for bullet in self.bullets:
            bullet.move( dt )
            bullet.checkBackWall( self.width )
                
        # update baddies
        for baddie in self.baddies:
            baddie.move( 0, 0, self.height, dt )

        # check for bullets destroying baddies
        for bullet in self.bullets:
            if not bullet.alive:
                continue

            for baddie in self.baddies:
                if not baddie.alive:
                    continue
                bullet.checkHitBaddie( baddie )
                if bullet.getHit( ):
                    bullet.setAlive( False )
                    baddie.setAlive( False )
                    bullet.hit = False

                    
        # remove deactivated bullets and baddies
        live_bullets = [ ]
        live_baddies = [ ]
        for bullet in self.bullets:
            if bullet.alive:
                live_bullets.append( bullet )
        for baddie in self.baddies:
            if baddie.alive:
                live_baddies.append( baddie )
      
        self.bullets = live_bullets
        self.baddies = live_baddies
            
        return

    def addBaddie( self ):
        x = self.width
        y = random.randint( 0, ( self.height - self.baddie_height ) )
        new_baddie = baddie.Baddie( self.baddie_width, self.baddie_height, x, y, self.baddie_color )
        self.baddies.append( new_baddie )
        return

    def draw( self, surface ):
        # fill the window background
        rect = pygame.Rect( 0, 0, self.width, self.height )
        surface.fill( ( 0, 0, 0 ), rect )
        
        # draw the objects in the game
        self.spaceship.draw( surface )
        for bullet in self.bullets:
            bullet.draw( surface )
        for baddie in self.baddies:
            baddie.draw( surface )
        return

    def drawTextLeft( self, surface, text, color, x, y, font ) :
        textobj = font.render( text, False, color )
        textrect = textobj.get_rect( )
        textrect.bottomleft = ( x, y )
        surface.blit( textobj, textrect )
        return

    def drawTextRight( self, surface, text, color, x, y, font ):
        textobj = font.render( text, False, color )
        textrect = textobj.get_rect( )
        textrect.bottomright = ( x, y )
        surface.blit( textobj, textrect )
        return
