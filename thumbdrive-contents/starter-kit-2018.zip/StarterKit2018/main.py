# YOU SHOULD CONFIGURE THESE TO MATCH YOUR GAME
# window title bar text
TITLE = "SpaceshipAdventure"
# pixels width
WINDOW_WIDTH  = 600
# pixels high
WINDOW_HEIGHT = 400
# frames per second
DESIRED_RATE  = 30

import pygame
import game
import game_program

class PygameApp( game.Game ):

    def __init__( self, title, width, height, frame_rate ):
        game.Game.__init__( self, title, width, height, frame_rate )
        self.newGame( width, height, frame_rate )
        return
    
    def game_logic( self, keys, newkeys, buttons, newbuttons, mouse_position, dt ):
        self.data.evolve( keys, newkeys, buttons, newbuttons, mouse_position, dt )
        return

    def paint( self, surface ):
        self.data.draw( surface )
        return
    
    def newGame( self, width, height, frame_rate ):
        self.width = width
        self.height = height
        self.frame_rate = frame_rate
        self.data = game_program.GameProgram( width, height, frame_rate )
        return


def main():
    pygame.font.init()
    game = PygameApp( TITLE, WINDOW_WIDTH, WINDOW_HEIGHT, DESIRED_RATE )
    game.main_loop( )
    return
    
if __name__ == "__main__":
    main()

