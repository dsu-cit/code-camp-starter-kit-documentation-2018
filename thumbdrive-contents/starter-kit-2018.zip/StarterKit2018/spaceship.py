import pygame
import bullet

class Spaceship:

    def __init__( self, width, height, x, y, color ):
        self.width  = width
        self.height = height
        self.x      = x
        self.y      = y
        self.speed  = 75
        self.color  = color
        return

    def moveLeft( self, dt ):
        self.x -= self.speed * dt
        # check the wall
        if self.x < 0:
            self.x = 0
        return

    def moveRight( self, dt, upper_limit ):
        self.x += self.speed * dt
        # check the wall
        if self.x > upper_limit:
            self.x = upper_limit
        return

    def moveUp( self, dt ):
        self.y -= self.speed * dt
        # check the wall
        if self.y < 0:
            self.y = 0
        return

    def moveDown( self, dt, board_height ):
        self.y += self.speed * dt
        # check the wall
        if self.y > board_height - self.height:
            self.y = board_height - self.height
        return

    def fire( self, width, height, color ):
        # center the bullet on the ship's right side
        x = ( self.x + self.width )
        y = ( self.y + (self.height /2) - (height/2) )
        b = bullet.Bullet( width, height, x, y, color )
        return b
    
    def draw( self, surface ):
        rect = pygame.Rect( int( self.x ), int( self.y ), int( self.width ), int( self.height ) )
        pygame.draw.rect( surface, self.color, rect )
        return
